# Harness Lab — 多 Agent 软件开发流水线实验

> 基于 OpenClaw + Harness Engineering 的多 Agent 协作实验

## 项目结构

```
harness-lab/
├── agents/
│   ├── supervisor/          ← 单会话主管 Agent（完整流水线）
│   ├── coordinator/         ← 协调者 Agent（多 Agent 模式）
│   ├── requirement/         ← 需求分析 Agent
│   ├── ui-designer/        ← UI 设计 Agent
│   ├── code-engineer/      ← 代码编写 Agent
│   ├── qa-engineer/        ← 代码测试 Agent
│   └── auditor/            ← 审计 Agent
├── memory/                  ← 各阶段输出存储
├── tasks/                  ← 测试任务
└── DESIGN.md               ← 设计文档
```

## 两种运行模式

### 模式A：单 Agent 全流程（简单，推荐新手）

直接告诉主管 Agent 你的需求，它在一个会话内完成所有阶段。

**使用方法：**
```
把 agents/supervisor/SOUL.md 的内容复制到你的 Agent 的 SOUL.md
然后直接提需求
```

---

### 模式B：多 Agent 协作（复杂，测试 Hook/Memory 价值）

启动多个独立 Agent，通过共享文件传递上下文。

**架构：**
```
用户
  ↓
Coordinator Agent（接收需求，分发任务）
  ↓
各专业 Agent（并行或顺序执行）
  ↓
共享 Memory 文件（上下文传递）
  ↓
Coordinator 汇总结果
```

---

## 测试任务

将需求文档放入 `tasks/` 目录，例如：

- `tasks/电商订单系统.md`
- `tasks/个人博客.md`
- `tasks/爬虫工具.md`

---

## 评估实验

### G1: 单 Agent 全流程
### G2: 多 Agent 顺序协作
### G3: 多 Agent + 共享 Memory
### G4: 多 Agent + Hook System

---

## 下一步

1. 查看 `DESIGN.md` 了解完整架构
2. 选择运行模式
3. 开始测试
