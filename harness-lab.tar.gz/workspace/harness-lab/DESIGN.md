# OpenClaw 多 Agent 软件开发流水线

> 基于 Harness Engineering 理念的多 Agent 协作实验
> 创建日期：2026-04-08

---

## 一、整体架构

```
用户/协调者
    │
    ▼
┌──────────────────────────────────────────────┐
│           Coordinator Agent (协调者)            │
│  负责任务分发、结果汇总、流程控制              │
└──────────────────┬─────────────────────────┘
                   │ 派发任务
     ┌─────────────┼─────────────┬────────────┐
     ▼             ▼             ▼            ▼
┌─────────┐ ┌──────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐
│需求分析 │ │  UI设计   │ │代码编写 │ │代码测试 │ │  审计   │
│  Agent  │ │  Agent   │ │  Agent  │ │  Agent  │ │  Agent  │
└────┬────┘ └────┬─────┘ └────┬────┘ └────┬────┘ └────┬────┘
     │            │            │            │            │
     └────────────┴────────────┴────────────┴────────────┘
                                    │
                              共享 Memory/
                              (上下文传递)
```

**协作流程：**
```
用户 → 提需求 → Coordinator
                ↓
         [需求分析 Agent] → 输出：需求文档.md
                ↓
         [UI设计 Agent] → 输出：UI设计稿.md
                ↓
         [代码编写 Agent] → 输出：源代码
                ↓
         [代码测试 Agent] → 输出：测试报告
                ↓
         [审计 Agent] → 输出：审计报告
                ↓
         Coordinator 汇总 → 用户
```

---

## 二、各 Agent 职责与 Prompt 设计

### 2.1 协调者 Agent（Coordinator）

**职责：**
- 接收用户需求
- 将任务分发给合适的 Agent
- 等待各 Agent 结果
- 汇总后返回给用户
- 控制流程顺序（需求→UI→代码→测试→审计）

**Prompt 模板：**
```
你是软件项目的协调者，负责管理软件开发流程。

流程顺序：
1. 需求分析
2. UI 设计
3. 代码编写
4. 代码测试
5. 审计

收到需求后：
1. 先调用需求分析 Agent
2. 等待结果后调用 UI 设计 Agent
3. 依次类推
4. 最终汇总所有结果返回给用户

当前任务：{用户需求}
```

### 2.2 需求分析 Agent（Requirement Agent）

**职责：**
- 分析用户需求
- 拆解功能点
- 明确技术约束
- 输出：需求文档.md

**Prompt 模板：**
```
你是资深需求分析师，擅长将模糊需求转化为清晰的功能规格说明。

输出格式（Markdown）：
# 需求文档

## 项目概述
{一句话描述项目}

## 功能列表
1. [功能1] - {描述}
2. [功能2] - {描述}

## 非功能需求
- 性能要求
- 安全要求
- 兼容性

## 技术约束
- 现有系统限制
- 技术栈要求

## 验收标准
{可测试的验收条件}
```

### 2.3 UI 设计 Agent（UI Designer Agent）

**职责：**
- 基于需求文档设计界面
- 输出 UI 描述（文本形式）
- 定义交互流程

**Prompt 模板：**
```
你是资深 UI/UX 设计师，擅长将功能需求转化为清晰的界面设计方案。

输入：需求文档.md

输出格式（Markdown）：
# UI 设计方案

## 页面结构
{列出所有页面及关系}

## 页面1：{页面名}
### 布局
{布局描述}

### 组件
| 组件 | 类型 | 状态 |
|------|------|------|

### 交互流程
{用户在此页面的操作流程}
```

### 2.4 代码编写 Agent（Code Engineer Agent）

**职责：**
- 根据需求和 UI 设计编写代码
- 遵循编码规范
- 生成完整可运行代码

**Prompt 模板：**
```
你是资深全栈工程师，根据需求文档和 UI 设计编写高质量代码。

编码原则：
1. 先规划后编码（先用伪代码/注释搭框架）
2. 模块化（每个模块单一职责）
3. 有注释（复杂逻辑必须注释）
4. 能跑通（代码必须可执行）

输出格式：
1. 先输出文件结构
2. 再输出每个文件代码
3. 最后输出运行说明
```

### 2.5 代码测试 Agent（QA Engineer Agent）

**职责：**
- 编写测试用例
- 执行测试
- 输出测试报告

**Prompt 模板：**
```
你是资深测试工程师，为代码编写全面的测试用例。

测试要求：
1. 测试覆盖所有函数
2. 边界条件测试
3. 异常情况测试
4. 给出 PASS/FAIL 结果

输出格式（Markdown）：
# 测试报告

## 测试用例列表
| 用例ID | 描述 | 输入 | 预期输出 | 结果 |

## 覆盖率
- 语句覆盖率：{X%}
- 分支覆盖率：{X}%

## 发现的问题
{列出失败的测试及原因}
```

### 2.6 审计 Agent（Auditor Agent）

**职责：**
- 代码审计（安全/性能/规范）
- 提出改进建议
- 最终质量评估

**Prompt 模板：**
```
你是资深架构师和安全专家，对代码进行全方位审计。

审计维度：
1. 安全性（SQL注入、XSS、认证授权等）
2. 性能（算法复杂度、资源占用等）
3. 代码规范（命名、注释、结构等）
4. 可维护性（耦合度、扩展性等）
5. 最佳实践

输出格式（Markdown）：
# 审计报告

## 总体评分
{1-10分}

## 问题列表
| 严重度 | 问题 | 位置 | 建议 |

## 优点总结
{做得好的地方}

## 最终建议
{是否可上线/需要修改/需要重写}
```

---

## 三、Agent 间的上下文传递

### 3.1 共享 Memory 文件

每个阶段完成后，结果写入共享文件，后续 Agent 读取：

```
harness-lab/
├── memory/
│   ├── 00_requirements.md   ← 需求分析结果
│   ├── 01_ui_design.md       ← UI 设计结果
│   ├── 02_source_code/       ← 源代码（多个文件）
│   ├── 03_test_report.md     ← 测试报告
│   ├── 04_audit_report.md    ← 审计报告
│   └── 05_final_report.md    ← 最终汇总
```

### 3.2 阶段间传递方式

```python
# 示例：代码编写 Agent 调用方式
def code_engineer_agent(requirements: str, ui_design: str) -> str:
    """
    接收：需求文档 + UI 设计文档
    返回：源代码
    """
    prompt = f"""
基于以下需求和UI设计编写代码：

=== 需求文档 ===
{requirements}

=== UI 设计 ===
{ui_design}

要求：
- 使用 Python 实现
- 包含完整的异常处理
- 附带单元测试
"""
    return call_llm(prompt)
```

---

## 四、OpenClaw 中的实现方式

### 4.1 创建各 Agent 的配置文件

在 workspace 下创建各 Agent 的 profile：

```
harness-lab/
├── agents/
│   ├── coordinator/
│   │   └── SOUL.md
│   ├── requirement/
│   │   └── SOUL.md
│   ├── ui-designer/
│   │   └── SOUL.md
│   ├── code-engineer/
│   │   └── SOUL.md
│   ├── qa-engineer/
│   │   └── SOUL.md
│   └── auditor/
│       └── SOUL.md
├── memory/
│   └── ...
└── tasks/
    └── ...
```

### 4.2 使用 sessions_spawn 创建子 Agent

通过 OpenClaw 的 sessions_spawn 工具启动各 Agent：

```python
# 启动需求分析 Agent
session_key = sessions_spawn(
    label="requirement-agent",
    runtime="subagent",
    task="你是需求分析 Agent，基于用户需求输出需求文档...",
)

# 获取结果
result = sessions_history(session_key=session_key)
```

### 4.3 简化方案：通过单一协调者实现

考虑到 OpenClaw 的实际限制（多 Agent 协作的复杂度），最简单的方式是：

**单一协调者 + 阶段化 Prompt：**

```python
def run_full_pipeline(user_requirement: str):
    # 阶段1：需求分析
    requirements = requirement_agent(user_requirement)

    # 阶段2：UI 设计
    ui_design = ui_designer_agent(requirements)

    # 阶段3：代码编写
    source_code = code_engineer_agent(requirements, ui_design)

    # 阶段4：代码测试
    test_report = qa_engineer_agent(source_code)

    # 阶段5：审计
    audit_report = auditor_agent(source_code, test_report)

    # 汇总
    return compile_final_report(
        requirements, ui_design, source_code, test_report, audit_report
    )
```

---

## 五、实验评估维度

### 5.1 评估指标

| 维度 | 指标 | 测量方式 |
|------|------|---------|
| **质量** | 代码可运行率、测试通过率 | 执行代码验证 |
| **效率** | 完成时间、Agent 调用次数 | 时间戳记录 |
| **上下文** | 需求传递完整度、文档一致性 | 人工评审 |
| **协作** | Agent 间信息丢失率 | 文档对比 |
| **成本** | Token 消耗、API 调用次数 | 日志统计 |

### 5.2 实验分组

| 实验组 | 配置 | 目的 |
|--------|------|------|
| **G1: 全流程单次** | 一个 Agent 完成所有阶段 | Baseline |
| **G2: 五阶段顺序** | 5个 Agent 顺序协作 | 测试协作效果 |
| **G3: 带 Memory** | G2 + 共享 memory 传递上下文 | 测试 Memory 价值 |
| **G4: 带 Hook** | G3 + 每个阶段后执行 Hook（如审计） | 测试 Hook 价值 |

---

## 六、下一步行动计划

### 阶段1：搭建骨架（本周）
- [ ] 创建 harness-lab/ 目录结构
- [ ] 编写各 Agent 的 SOUL.md
- [ ] 实现协调者 Agent 的阶段化流程

### 阶段2：单 Agent 调试（本周）
- [ ] 调试需求分析 Agent
- [ ] 调试 UI 设计 Agent
- [ ] 调试代码编写 Agent
- [ ] 调试测试 Agent
- [ ] 调试审计 Agent

### 阶段3：协作实验（第二周）
- [ ] 实现顺序协作流程
- [ ] 记录各阶段上下文传递质量
- [ ] 运行 G1 vs G2 对比实验

### 阶段4：系统化评估（第二周）
- [ ] 建立评估指标体系
- [ ] 运行 G3 vs G4 对比实验
- [ ] 输出实验报告
