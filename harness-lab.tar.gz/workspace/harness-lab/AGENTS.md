# AGENTS.md — Harness Lab 本身

## 项目目标

通过实验对比，验证 Harness Engineering 四大理念在不同 Agent 协作场景下的实际价值。

## 实验设计

### 对比维度

| 实验 | 配置 | 验证假设 |
|------|------|---------|
| G1 | 单 Agent 完成全流程 | Baseline |
| G2 | 5个 Agent 顺序协作 | 专业化分工是否带来质量提升 |
| G3 | G2 + 共享 Memory | Memory 是否减少上下文信息丢失 |
| G4 | G3 + Hook System | Hook 是否改善流程可控性 |

### 评估指标

- **质量**：代码可运行率、测试通过率
- **效率**：完成时间、Token 消耗
- **一致性**：各阶段输出的一致程度
- **上下文保留**：后续 Agent 对前序阶段的理解准确率

## 当前 Agent 列表

| Agent | 角色 | 配置文件 |
|-------|------|---------|
| supervisor | 主管（全流程） | agents/supervisor/SOUL.md |
| coordinator | 协调者（多 Agent） | agents/coordinator/SOUL.md |
| requirement | 需求分析师 | agents/requirement/SOUL.md |
| ui-designer | UI 设计师 | agents/ui-designer/SOUL.md |
| code-engineer | 代码工程师 | agents/code-engineer/SOUL.md |
| qa-engineer | 测试工程师 | agents/qa-engineer/SOUL.md |
| auditor | 审计师 | agents/auditor/SOUL.md |

## 使用方法

### 快速测试

1. 复制 `agents/supervisor/SOUL.md` 内容到你的 Agent SOUL.md
2. 在同一会话中提出需求
3. Agent 将在一个会话内完成全部 5 个阶段

### 多 Agent 测试

通过 sessions_spawn 启动多个子 Agent，参考 DESIGN.md 中的架构

## 记录规范

实验结果记录在 `memory/` 目录：
- `memory/experiments/` — 各实验组结果
- `memory/observations/` — 观察记录
